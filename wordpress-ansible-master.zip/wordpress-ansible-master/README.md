# wordpress-ansible

Tested on *Ubuntu 16.04.2 LTS*

```
sudo ansible-playbook playbook.yml -i hosts -e mysql_root_password=#password#
```

